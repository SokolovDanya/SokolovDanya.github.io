﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WpfAppLab
{
    public static class ImageProcessor
    {
        public static WriteableBitmap GetChannel(WriteableBitmap src, string channel)
        {
            int stride = src.PixelWidth * 4;
            byte[] pixels = new byte[src.PixelHeight * stride];
            src.CopyPixels(pixels, stride, 0);

            for (int i = 0; i < pixels.Length; i += 4)
            {
                byte r = pixels[i + 2];
                byte g = pixels[i + 1];
                byte b = pixels[i];

                byte val = 0;
                switch (channel)
                {
                    case "R": val = r; break;
                    case "G": val = g; break;
                    case "B": val = b; break;
                }

                pixels[i] = val;     // B
                pixels[i + 1] = val; // G
                pixels[i + 2] = val; // R
                pixels[i + 3] = 255; // A
            }

            return CreateWriteableBitmap(src.PixelWidth, src.PixelHeight, pixels);
        }

        public static WriteableBitmap ToGrayscale(WriteableBitmap src)
        {
            int stride = src.PixelWidth * 4;
            byte[] pixels = new byte[src.PixelHeight * stride];
            src.CopyPixels(pixels, stride, 0);

            for (int i = 0; i < pixels.Length; i += 4)
            {
                byte r = pixels[i + 2];
                byte g = pixels[i + 1];
                byte b = pixels[i];
                byte gray = (byte)(0.299 * r + 0.587 * g + 0.114 * b);

                pixels[i] = gray;
                pixels[i + 1] = gray;
                pixels[i + 2] = gray;
                pixels[i + 3] = 255;
            }

            return CreateWriteableBitmap(src.PixelWidth, src.PixelHeight, pixels);
        }

        public static WriteableBitmap ToSepia(WriteableBitmap src)
        {
            int stride = src.PixelWidth * 4;
            byte[] pixels = new byte[src.PixelHeight * stride];
            src.CopyPixels(pixels, stride, 0);

            for (int i = 0; i < pixels.Length; i += 4)
            {
                byte r = pixels[i + 2];
                byte g = pixels[i + 1];
                byte b = pixels[i];

                byte tr = (byte)(0.393 * r + 0.769 * g + 0.189 * b);
                byte tg = (byte)(0.349 * r + 0.686 * g + 0.168 * b);
                byte tb = (byte)(0.272 * r + 0.534 * g + 0.131 * b);

                pixels[i] = tb;
                pixels[i + 1] = tg;
                pixels[i + 2] = tr;
                pixels[i + 3] = 255;
            }

            return CreateWriteableBitmap(src.PixelWidth, src.PixelHeight, pixels);
        }

        public static WriteableBitmap AdjustBrightnessContrast(WriteableBitmap src, double brightness, double contrast)
        {
            int stride = src.PixelWidth * 4;
            byte[] pixels = new byte[src.PixelHeight * stride];
            src.CopyPixels(pixels, stride, 0);

            double factor = (259 * (contrast + 255)) / (255 * (259 - contrast));

            for (int i = 0; i < pixels.Length; i += 4)
            {
                double r = pixels[i + 2];
                double g = pixels[i + 1];
                double b = pixels[i];

                r = factor * (r - 128) + 128 + brightness;
                g = factor * (g - 128) + 128 + brightness;
                b = factor * (b - 128) + 128 + brightness;

                pixels[i] = (byte)Clamp(b, 0, 255);
                pixels[i + 1] = (byte)Clamp(g, 0, 255);
                pixels[i + 2] = (byte)Clamp(r, 0, 255);
                pixels[i + 3] = 255;
            }

            return CreateWriteableBitmap(src.PixelWidth, src.PixelHeight, pixels);
        }

        public static WriteableBitmap LogicalOperation(WriteableBitmap img1, WriteableBitmap img2, string op)
        {
            if (img1.PixelWidth != img2.PixelWidth || img1.PixelHeight != img2.PixelHeight)
                throw new ArgumentException("Изображения должны быть одинакового размера.");

            int w = img1.PixelWidth, h = img1.PixelHeight;
            int stride = w * 4;

            byte[] p1 = new byte[h * stride], p2 = new byte[h * stride];
            img1.CopyPixels(p1, stride, 0);
            img2.CopyPixels(p2, stride, 0);

            byte[] result = new byte[h * stride];

            for (int i = 0; i < p1.Length; i += 4)
            {
                Color c1 = Color.FromArgb(p1[i + 3], p1[i + 2], p1[i + 1], p1[i]);
                Color c2 = Color.FromArgb(p2[i + 3], p2[i + 2], p2[i + 1], p2[i]);

                Color res = Colors.Black;

                switch (op)
                {
                    case "NOT": res = Color.FromArgb(255, (byte)(255 - c1.R), (byte)(255 - c1.G), (byte)(255 - c1.B)); break;
                    case "XOR": res = Color.FromArgb(255, (byte)(c1.R ^ c2.R), (byte)(c1.G ^ c2.G), (byte)(c1.B ^ c2.B)); break;
                    case "AND": res = Color.FromArgb(255, (byte)(c1.R & c2.R), (byte)(c1.G & c2.G), (byte)(c1.B & c2.B)); break;
                }

                result[i] = res.B;
                result[i + 1] = res.G;
                result[i + 2] = res.R;
                result[i + 3] = 255;
            }

            return CreateWriteableBitmap(w, h, result);
        }

        public static WriteableBitmap ToHSVAndAdjust(WriteableBitmap src, double hShift, double sFactor, double vFactor)
        {
            int stride = src.PixelWidth * 4;
            byte[] pixels = new byte[src.PixelHeight * stride];
            src.CopyPixels(pixels, stride, 0);


            for (int i = 0; i < pixels.Length; i += 4)
            {
                Color c = Color.FromArgb(pixels[i + 3], pixels[i + 2], pixels[i + 1], pixels[i]);

                //double h, s, v;
                RGBToHSV(c.R, c.G, c.B, out double h, out double s, out double v);

                //RGBToHSV(c.R, c.G, c.B, out h, out s, out v);

                h = (h + hShift) % 360;
                s = Math.Min(Math.Max(s * sFactor, 0), 1);
                v = Math.Min(Math.Max(v * vFactor, 0), 1);

                Color c2 = HSVToRGB(h, s, v);
                pixels[i] = c2.B;
                pixels[i + 1] = c2.G;
                pixels[i + 2] = c2.R;
                pixels[i + 3] = 255;
            }

            return CreateWriteableBitmap(src.PixelWidth, src.PixelHeight, pixels);
        }

        public static WriteableBitmap MedianBlur(WriteableBitmap src, int kernelSize = 3)
        {
            int w = src.PixelWidth, h = src.PixelHeight;
            int stride = w * 4;
            byte[] pixels = new byte[h * stride];
            src.CopyPixels(pixels, stride, 0);

            byte[] result = new byte[h * stride];

            int radius = kernelSize / 2;

            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    List<byte> rList = new List<byte>();
                    List<byte> gList = new List<byte>();
                    List<byte> bList = new List<byte>();

                    for (int ky = -radius; ky <= radius; ky++)
                    {
                        for (int kx = -radius; kx <= radius; kx++)
                        {
                            int nx = x + kx;
                            int ny = y + ky;

                            if (nx >= 0 && nx < w && ny >= 0 && ny < h)
                            {
                                int idx = (ny * w + nx) * 4;
                                rList.Add(pixels[idx + 2]);
                                gList.Add(pixels[idx + 1]);
                                bList.Add(pixels[idx]);
                            }
                        }
                    }

                    rList.Sort(); gList.Sort(); bList.Sort();
                    int mid = rList.Count / 2;

                    int dstIdx = (y * w + x) * 4;
                    result[dstIdx] = bList[mid];
                    result[dstIdx + 1] = gList[mid];
                    result[dstIdx + 2] = rList[mid];
                    result[dstIdx + 3] = 255;
                }
            }

            return CreateWriteableBitmap(w, h, result);
        }

        public static WriteableBitmap ConvolutionFilter(WriteableBitmap src, double[,] kernel, double factor = 1.0, double bias = 0.0)
        {
            int w = src.PixelWidth, h = src.PixelHeight;
            int kSize = kernel.GetLength(0);
            int radius = kSize / 2;
            int stride = w * 4;

            byte[] pixels = new byte[h * stride];
            src.CopyPixels(pixels, stride, 0);

            byte[] result = new byte[h * stride];

            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    double r = 0, g = 0, b = 0;

                    for (int ky = -radius; ky <= radius; ky++)
                    {
                        for (int kx = -radius; kx <= radius; kx++)
                        {
                            int nx = x + kx;
                            int ny = y + ky;

                            if (nx >= 0 && nx < w && ny >= 0 && ny < h)
                            {
                                int srcIdx = (ny * w + nx) * 4;
                                r += pixels[srcIdx + 2] * kernel[ky + radius, kx + radius];
                                g += pixels[srcIdx + 1] * kernel[ky + radius, kx + radius];
                                b += pixels[srcIdx] * kernel[ky + radius, kx + radius];
                            }
                        }
                    }

                    r = factor * r + bias;
                    g = factor * g + bias;
                    b = factor * b + bias;

                    int dstIdx = (y * w + x) * 4;
                    result[dstIdx] = (byte)Clamp(b, 0, 255);
                    result[dstIdx + 1] = (byte)Clamp(g, 0, 255);
                    result[dstIdx + 2] = (byte)Clamp(r, 0, 255);
                    result[dstIdx + 3] = 255;
                }
            }

            return CreateWriteableBitmap(w, h, result);
        }

        private static WriteableBitmap CreateWriteableBitmap(int width, int height, byte[] pixels)
        {
            WriteableBitmap wb = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);
            wb.WritePixels(new Int32Rect(0, 0, width, height), pixels, width * 4, 0);
            return wb;
        }

        private static double Clamp(double value, double min, double max)
        {
            return value < min ? min : value > max ? max : value;
        }

        private static void RGBToHSV(byte r, byte g, byte b, out double h, out double s, out double v)
        {
            double rf = r / 255.0, gf = g / 255.0, bf = b / 255.0;
            double max = Math.Max(rf, Math.Max(gf, bf));
            double min = Math.Min(rf, Math.Min(gf, bf));

            v = max;
            if (max == 0) { s = 0; h = 0; return; }

            s = (max - min) / max;

            if (max == rf) h = (60 * (gf - bf) / (max - min)) % 6;
            else if (max == gf) h = (60 * (bf - rf) / (max - min)) + 2;
            else h = (60 * (rf - gf) / (max - min)) + 4;

            h *= 60;
            if (h < 0) h += 360;
        }

        private static Color HSVToRGB(double h, double s, double v)
        {
            h /= 60;
            int i = (int)Math.Floor(h);
            double f = h - i;
            double p = v * (1 - s);
            double q = v * (1 - s * f);
            double t = v * (1 - s * (1 - f));

            Color c;
            switch (i)
            {
                case 0: c = Color.FromRgb((byte)(v * 255), (byte)(t * 255), (byte)(p * 255)); break;
                case 1: c = Color.FromRgb((byte)(q * 255), (byte)(v * 255), (byte)(p * 255)); break;
                case 2: c = Color.FromRgb((byte)(p * 255), (byte)(v * 255), (byte)(t * 255)); break;
                case 3: c = Color.FromRgb((byte)(p * 255), (byte)(q * 255), (byte)(v * 255)); break;
                case 4: c = Color.FromRgb((byte)(t * 255), (byte)(p * 255), (byte)(v * 255)); break;
                default: c = Color.FromRgb((byte)(v * 255), (byte)(p * 255), (byte)(q * 255)); break;
            }
            return c;
        }
    }
}

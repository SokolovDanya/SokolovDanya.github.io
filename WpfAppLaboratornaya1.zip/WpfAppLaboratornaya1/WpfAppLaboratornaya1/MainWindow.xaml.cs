﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;

namespace WpfAppLab
{
  
    public partial class MainWindow : Window
    {
        private WriteableBitmap originalBitmap;
        private WriteableBitmap resultBitmap;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoadImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "Image files (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp|All files (*.*)|*.*"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    var bitmap = new BitmapImage(new Uri(dialog.FileName));
                    originalBitmap = new WriteableBitmap(bitmap);
                    OriginalImage.Source = bitmap;
                    ResultImage.Source = null;
                    StatusText.Text = $"Loaded: {dialog.FileName}";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading image: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void Channel_Click(object sender, RoutedEventArgs e)
        {
            if (originalBitmap == null) return;

            string channel = ((ComboBoxItem)ChannelCombo.SelectedItem).Content.ToString();
            resultBitmap = ImageProcessor.GetChannel(originalBitmap, channel.Substring(0, 1));
            ResultImage.Source = resultBitmap;
            StatusText.Text = $"Channel: {channel}";
        }

        private void Grayscale_Click(object sender, RoutedEventArgs e)
        {
            if (originalBitmap == null) return;

            resultBitmap = ImageProcessor.ToGrayscale(originalBitmap);
            ResultImage.Source = resultBitmap;
            StatusText.Text = "Grayscale applied";
        }

        private void Sepia_Click(object sender, RoutedEventArgs e)
        {
            if (originalBitmap == null) return;

            resultBitmap = ImageProcessor.ToSepia(originalBitmap);
            ResultImage.Source = resultBitmap;
            StatusText.Text = "Sepia applied";
        }

        private void BrightnessContrast_Click(object sender, RoutedEventArgs e)
        {
            if (originalBitmap == null) return;

            double brightness = BrightnessSlider.Value;
            double contrast = ContrastSlider.Value;
            resultBitmap = ImageProcessor.AdjustBrightnessContrast(originalBitmap, brightness, contrast);
            ResultImage.Source = resultBitmap;
            StatusText.Text = $"Brightness: {brightness}, Contrast: {contrast}";
        }

        private void LogicalOp_Click(object sender, RoutedEventArgs e)
        {
            if (originalBitmap == null || resultBitmap == null) return;

            string op = ((ComboBoxItem)LogicCombo.SelectedItem).Content.ToString().Split(' ')[0];
            resultBitmap = ImageProcessor.LogicalOperation(originalBitmap, resultBitmap, op);
            ResultImage.Source = resultBitmap;
            StatusText.Text = $"Logical op: {op}";
        }

        private void HSVAdjust_Click(object sender, RoutedEventArgs e)
        {
            if (originalBitmap == null) return;

            double hShift = HS_Slider.Value;
            double sFactor = SV_Slider.Value;
            double vFactor = SV_Slider.Value;
            resultBitmap = ImageProcessor.ToHSVAndAdjust(originalBitmap, hShift, sFactor, vFactor);
            ResultImage.Source = resultBitmap;
            StatusText.Text = $"HSV: H={hShift}°, S×{sFactor:F2}, V×{vFactor:F2}";
        }

        private void MedianBlur_Click(object sender, RoutedEventArgs e)
        {
            if (originalBitmap == null) return;

            int size = int.Parse(((ComboBoxItem)BlurCombo.SelectedItem).Content.ToString().Replace("x", ""));
            resultBitmap = ImageProcessor.MedianBlur(originalBitmap, size);
            ResultImage.Source = resultBitmap;
            StatusText.Text = $"Median blur: {size}×{size}";
        }

        private void CustomFilter_Click(object sender, RoutedEventArgs e)
        {
            if (originalBitmap == null) return;

            try
            {
                string[] rows = KernelText.Text.Split('|');
                int size = rows.Length;
                double[,] kernel = new double[size, size];

                for (int i = 0; i < size; i++)
                {
                    string[] values = rows[i].Split(',');
                    for (int j = 0; j < size; j++)
                    {
                        kernel[i, j] = double.Parse(values[j]);
                    }
                }

                resultBitmap = ImageProcessor.ConvolutionFilter(originalBitmap, kernel);
                ResultImage.Source = resultBitmap;
                StatusText.Text = "Custom filter applied";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Invalid kernel format: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}



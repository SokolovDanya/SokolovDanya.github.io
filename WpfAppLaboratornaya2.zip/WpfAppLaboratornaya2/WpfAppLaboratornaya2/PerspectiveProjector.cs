﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace WpfAppLab
{
    class PerspectiveProjector
    {
        public static Geometry GetQuadGeometry(Point[] points)
        {
            if (points.Length != 4) throw new ArgumentException("Требуется 4 точки");

            var stream = new StreamGeometry();
            using (var context = stream.Open())
            {
                context.BeginFigure(points[0], true, true);
                context.LineTo(points[1], true, true);
                context.LineTo(points[2], true, true);
                context.LineTo(points[3], true, true);
            }
            stream.Freeze();
            return stream;
        }
    }
}

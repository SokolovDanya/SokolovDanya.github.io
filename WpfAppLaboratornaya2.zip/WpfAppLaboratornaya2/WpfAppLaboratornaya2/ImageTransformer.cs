﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WpfAppLab
{
    public class ImageTransformer
    {
        public static BitmapSource Scale(BitmapSource source, double scaleX, double scaleY)
        {
            var transform = new ScaleTransform(scaleX, scaleY);
            return ApplyTransform(source, transform);
        }

        public static BitmapSource Translate(BitmapSource source, double offsetX, double offsetY)
        {
            // Создаём DrawingVisual для отрисовки со сдвигом
            var visual = new DrawingVisual();
            using (var dc = visual.RenderOpen())
            {
                dc.DrawImage(source, new Rect(offsetX, offsetY, source.PixelWidth, source.PixelHeight));
            }

            // Рендерим в новый BitmapSource с учётом сдвига
            var width = (int)(source.PixelWidth + Math.Abs(offsetX));
            var height = (int)(source.PixelHeight + Math.Abs(offsetY));

            var bitmap = new RenderTargetBitmap(
                width, height,
                96, 96, PixelFormats.Pbgra32);

            bitmap.Render(visual);

            return bitmap;
        }
        public static BitmapSource Rotate(BitmapSource source, double angle, Point center)
        {
            var transform = new RotateTransform(angle, center.X, center.Y);
            return ApplyTransform(source, transform);
        }

        public static BitmapSource Flip(BitmapSource source, FlipMode mode)
        {
            ScaleTransform transform;
            switch (mode)
            {
                case FlipMode.Horizontal:
                    transform = new ScaleTransform(-1, 1);
                    transform.CenterX = source.PixelWidth / 2.0;
                    break;
                case FlipMode.Vertical:
                    transform = new ScaleTransform(1, -1);
                    transform.CenterY = source.PixelHeight / 2.0;
                    break;
                case FlipMode.Both:
                    transform = new ScaleTransform(-1, -1);
                    transform.CenterX = source.PixelWidth / 2.0;
                    transform.CenterY = source.PixelHeight / 2.0;
                    break;
                default:
                    return source;
            }
            return ApplyTransform(source, transform);
        }

        public static BitmapSource ApplyBilinearFilter(BitmapSource source)
        {
            // В WPF билинейная фильтрация включается через RenderOptions
            var transformed = new TransformedBitmap(source, new ScaleTransform(1, 1));
            RenderOptions.SetBitmapScalingMode(transformed, BitmapScalingMode.HighQuality);
            return transformed;
        }

        private static BitmapSource ApplyTransform(BitmapSource source, Transform transform)
        {
            var transformed = new TransformedBitmap(source, transform);
            RenderOptions.SetBitmapScalingMode(transformed, BitmapScalingMode.HighQuality);
            return transformed;
        }

        public enum FlipMode
        {
            Horizontal,
            Vertical,
            Both
        }
    }
}

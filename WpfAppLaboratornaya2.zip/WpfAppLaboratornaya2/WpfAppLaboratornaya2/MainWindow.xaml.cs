﻿using System;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace WpfAppLab
{
    public partial class MainWindow : Window
    {
        private BitmapSource _originalImage;
        private Point[] _projectionPoints = new Point[4];
        private int _pointIndex = 0;

        public MainWindow()
        {
            InitializeComponent();
            // Инициализируем поле
            _originalImage = new BitmapImage(); // Пустое изображение
        }
        //Загрузка изображения
        private void LoadImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp|Все файлы|*.*"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    // Используем using для автоматического закрытия потока
                    using (var stream = new FileStream(dialog.FileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        var bitmap = new BitmapImage();
                        bitmap.BeginInit();
                        bitmap.CacheOption = BitmapCacheOption.OnLoad; // Загружаем полностью
                        bitmap.StreamSource = stream;
                        bitmap.EndInit();
                        bitmap.Freeze(); // Для потокобезопасности

                        _originalImage = bitmap;
                        OriginalImage.Source = _originalImage;
                        ProcessedImage.Source = _originalImage;
                    }
                }
                catch (IOException ex)
                {
                    MessageBox.Show($"Ошибка доступа к файлу: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Неизвестная ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        //Масштабирование
        private void Scale_Click(object sender, RoutedEventArgs e)
        {
            if (_originalImage == null) return;

            double scaleX, scaleY;
            if (!double.TryParse(ScaleXBox.Text, out scaleX) ||
                !double.TryParse(ScaleYBox.Text, out scaleY))
            {
                MessageBox.Show("Введите корректные значения масштаба (числа).");
                return;
            }

            var scaled = ImageTransformer.Scale(_originalImage, scaleX, scaleY);
            ProcessedImage.Source = scaled;
        }
        //Сдвиг
        private void Translate_Click(object sender, RoutedEventArgs e)
        {
            if (_originalImage == null) return;

            double offsetX, offsetY;
            if (!double.TryParse(OffsetXBox.Text, out offsetX) ||
                !double.TryParse(OffsetYBox.Text, out offsetY))
            {
                MessageBox.Show("Введите корректные значения сдвига (числа).");
                return;
            }

            var translated = ImageTransformer.Translate(_originalImage, offsetX, offsetY);
            ProcessedImage.Source = translated;
        }
        //Поворот
        private void Rotate_Click(object sender, RoutedEventArgs e)
        {
            if (_originalImage == null) return;

            double angle;
            if (!double.TryParse(AngleBox.Text, out angle))
            {
                MessageBox.Show("Введите корректный угол поворота (число).");
                return;
            }

            // Центр вращения — центр изображения
            var center = new Point(
                _originalImage.PixelWidth / 2.0,
                _originalImage.PixelHeight / 2.0);

            var rotated = ImageTransformer.Rotate(_originalImage, angle, center);
            ProcessedImage.Source = rotated;
        }
        //Отражение
        private void FlipHorizontal_Click(object sender, RoutedEventArgs e)
        {
            if (_originalImage == null) return;
            var flipped = ImageTransformer.Flip(_originalImage, ImageTransformer.FlipMode.Horizontal);
            ProcessedImage.Source = flipped;
        }

        private void FlipVertical_Click(object sender, RoutedEventArgs e)
        {
            if (_originalImage == null) return;
            var flipped = ImageTransformer.Flip(_originalImage, ImageTransformer.FlipMode.Vertical);
            ProcessedImage.Source = flipped;
        }

        private void FlipBoth_Click(object sender, RoutedEventArgs e)
        {
            if (_originalImage == null) return;
            var flipped = ImageTransformer.Flip(_originalImage, ImageTransformer.FlipMode.Both);
            ProcessedImage.Source = flipped;
        }
        //Проекция
        private void Perspective_Click(object sender, RoutedEventArgs e)
        {
            if (_originalImage == null)
            {
                MessageBox.Show("Загрузите изображение сначала.");
                return;
            }

            // Переходим в режим выбора точек
            MessageBox.Show("Кликните по 4 точкам на изображении для определения проекции.\n" +
                           "Порядок: левый верхний → правый верхний → правый нижний → левый нижний.");

            ProcessedImage.MouseDown += ProcessedImage_MouseDown;
            _pointIndex = 0;
        }

        private void ProcessedImage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (_pointIndex >= 4) return;

            // Получаем координаты клика в системе координат изображения
            var pos = e.GetPosition(ProcessedImage);
            _projectionPoints[_pointIndex] = pos;
            _pointIndex++;

            if (_pointIndex == 4)
            {
                // Все точки собраны — выполняем проекцию
                ProcessedImage.MouseDown -= ProcessedImage_MouseDown;
                ApplyPerspectiveProjection();
            }
        }

        private void ApplyPerspectiveProjection()
        {
            // В данной реализации мы просто рисуем контур выбранных точек
            var geometry = PerspectiveProjector.GetQuadGeometry(_projectionPoints);

            var drawingVisual = new DrawingVisual();
            using (var dc = drawingVisual.RenderOpen())
            {
                dc.DrawImage(_originalImage, new Rect(0, 0,
                    ProcessedImage.ActualWidth, ProcessedImage.ActualHeight));
                dc.DrawGeometry(Brushes.Transparent, new Pen(Brushes.Red, 2), geometry);
            }

            var bitmap = new RenderTargetBitmap(
                (int)ProcessedImage.ActualWidth,
                (int)ProcessedImage.ActualHeight,
                96, 96, PixelFormats.Pbgra32);
            bitmap.Render(drawingVisual);

            ProcessedImage.Source = bitmap;
        }
    }
}